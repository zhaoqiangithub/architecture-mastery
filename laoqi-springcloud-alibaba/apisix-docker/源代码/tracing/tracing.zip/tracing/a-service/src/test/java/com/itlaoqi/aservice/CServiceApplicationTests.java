package com.itlaoqi.aservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
